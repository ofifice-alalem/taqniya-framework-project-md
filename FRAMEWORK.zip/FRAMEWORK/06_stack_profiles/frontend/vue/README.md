# Vue 3 Technology Profile

# Purpose
This profile defines framework-specific implementation patterns, coding rules, state management, and testing practices for **Vue 3 (Composition API / Nuxt)** applications under the Taqniya Framework.

---

## 1. Supported Ecosystem & Defaults

- **Language:** TypeScript (`strict: true`) with `<script setup lang="ts">`
- **Routing:** Vue Router v4 or Nuxt Pages
- **State Management:**
  - Client UI State: `Pinia`
  - Server State: `TanStack Query Vue` or `useFetch` (Nuxt)
- **Virtualization:** `vue-virtual-scroller` or `TanStack Virtual Vue`
- **Testing:** `Vitest` + `Vue Test Utils` + `Playwright`
- **Styling:** Tailwind CSS + Taqniya CSS Tokens

---

## 2. Profile Documents

- [`architecture.md`](architecture.md): SFC organization, composable boundaries, and feature structure.
- [`coding_rules.md`](coding_rules.md): `<script setup>`, Props/Emits typing, and reactivity hygiene.
- [`state.md`](state.md): Pinia stores, server caching, and storeToRefs.
- [`performance.md`](performance.md): `defineAsyncComponent`, `shallowRef`, and virtualization.
- [`testing.md`](testing.md): Component tests with Vitest and user interactions.
