# React Technology Profile

# Purpose
This profile defines framework-specific implementation patterns, coding rules, state management, and testing practices for **React (v18 / v19 / Next.js)** applications under the Taqniya Framework.

---

## 1. Supported Ecosystem & Defaults

- **Language:** TypeScript (`strict: true`)
- **Routing:** React Router v6+ or Next.js App Router
- **State Management:**
  - Client UI State: `Zustand`
  - Server State & Cache: `TanStack Query` (React Query)
- **Virtualization:** `TanStack Virtual`
- **Testing:** `Vitest` + `React Testing Library` + `Playwright`
- **Styling:** Tailwind CSS + Taqniya CSS Tokens

---

## 2. Profile Documents

- [`architecture.md`](architecture.md): Component hierarchy, folder structures, and boundary rules.
- [`coding_rules.md`](coding_rules.md): React Hooks invariants, clean JSX, and TypeScript typing.
- [`state.md`](state.md): Zustand stores, TanStack Query hooks, and selective subscriptions.
- [`performance.md`](performance.md): `React.lazy`, `useMemo`, `useCallback`, and virtualization patterns.
- [`testing.md`](testing.md): Testing React components, user interactions, and mocking.
